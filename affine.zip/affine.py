import sys
def existinv(a):
	r1=256
	r2=a
	t1=0
	t2=1
	t=""
	while(r2>0):
		q=int(r1/r2)
		r=r1%r2
		t=t1+t2*q
		t1=t2
		t2=t	
		r1=r2
		r2=r		
	if(r1==1):
		r1=t1
	else:
		r1=0
	return r1
def inv(a):
	c=1
	while(True):
		if((a*c)%256==1):
			break
		else:
			c=c+1
			continue
	return c

p="abcdefghijklmnopqrstuvwxyz"
p=list(p) 
cipher=""
plaintext=open("inp.txt","r+").read()

k1=int(input("enter key 1"))
k2=int(input("enter key 2"))
#if(not (k2<26 and k2>=0)):

#	print("key 2 is not valid")
#	sys.exit(0)
kt1=existinv(k1)
print("incerse",kt1)
if(kt1==0):
	print("key 1 is not valid")
	sys.exit(0)
for i in plaintext:
	z=i
	cipher=cipher+chr(((ord(z))*k1+k2)%256)
print(cipher)
k1=inv(k1)
dec=""
for i in cipher:
	dec=dec+chr(((ord(i)-k2)*k1)%256)
	
print(dec)		
p1=open("out.txt","w+")
p1.write(dec)
