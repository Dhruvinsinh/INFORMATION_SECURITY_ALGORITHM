import numpy
key_len=int(input("enter length of key"))
plaintext=open("inp.txt","r+").read()
a=[]
key=[]
enc=[]
dec=[]
def s(k1):
	count=1
	p=numpy.arange(len(k1))
	p=list(p)
	a="abcdefghijklmnopqrstuvwxyz"
	a=list(a)
	for i in a:
		for j in range(0,len(k1)):
			if(i==k1[j].lower()):
				p[j]=count
				count=count+1
	return p
for i in plaintext:
	a.append(i)
temp1=len(a)
temp2=temp1%key_len
if(temp2!=0):
	temp2=int(temp1/key_len)
	temp2=temp2+1
	temp3=temp2*key_len
	temp4=temp3-temp1	
	for i in range(0,temp4):
		  a.append('z')
for i in range(0,len(a)):
	enc.append('z')
	dec.append('z')
t_l=len(a)
a=numpy.array(a)
a=a.reshape(-1,key_len)
print(a)
enc=numpy.array(enc)
enc=enc.reshape(-1,key_len)
dec=numpy.array(dec)
dec=dec.reshape(-1,key_len)

for i in range(0,key_len):
	key.append(input("enter key"))	
key=s(key)
print("key",key)
col=key_len
row=int(t_l/col)
col2=0
for i in key:
	s_c=int(i)
	s_c=s_c-1
	for j in range(0,row):
		
		enc[j][col2]=a[j][s_c]	
	col2=col2+1
print(enc)
decryption_key=[]

for i in range(1,key_len+1):
	z=i
	decryption_key.append(key.index(z)+1)
print(decryption_key)
col2=0
for i in decryption_key:
	s_c=int(i)
	s_c=s_c-1
	for j in range(0,row):
		dec[j][col2]=enc[j][s_c]	
	col2=col2+1
print(dec)
dec=dec.reshape(-1)
dec=list(dec)
dec=str(dec)
print(dec)

dec=dec.replace('z','')
dec=dec.replace(', ','')
dec=dec.replace('\\n','')
final=""
a="abcdefghijklmnopqrstuvwxyz"
a=list(a)
for i in dec:
	if(i.lower() in a or i==" "):
		final=final+i
	
print(final)
p=open("out.txt","w+")
p.write(final)
