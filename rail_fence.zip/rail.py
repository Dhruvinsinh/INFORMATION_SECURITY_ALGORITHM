import sys,numpy
def decconvert(matrix,z):
	row,col=matrix.shape
	k=0
	s=0
	i=0	
	message=""
	while(i<col):
		for j in range(0,row):
			if(matrix[j][i]==None):
				continue
			else:
				print(matrix[j][i],end="")
				message=message+matrix[j][i]
				break
		i=i+1
	return message
	
def encryption():
	d=-1
	while(d<=1):
		d=int(input("enter depth"))

	p=open("enc.txt","r+").read()
	z=""
	z1=0
	
	for i in range(0,d):
		k=(d-i)*2-3
	
		if(i==0):
			k11=k
			z1=k
			z1=z1-1
		
		if(k<0):
			k=d
		print(" "*i,end="")
		if(i==0 or i==(d-1)):
			for j in range(i,len(p),(k11+1)):
				z=z+p[j]
				print(p[j]+" "*k11,end="")
			
		else:
			j=i
			while(j<len(p)):
				z=z+p[j]
				print(p[j],end="")
				print(" "*k,end="")
				j=j+k+1
				k=z1-k
			

		print("")
	print(z)
	f1=open("encrypted.txt","w+")
	f1.write(z)
encryption()
def decryption(z,d,cry=0):
	matrix=[]
	for i in range(0,len(z)*d):
		matrix.append(None)
	matrix=numpy.array(matrix)
	matrix=matrix.reshape(-1,len(z))	
	mp=0	
	i=0
	row=0
	dec=""
	while(i<len(z)):
		d1=(d-row)*2-3
		if(row==0):
			k11=d1
			z1=d1
			z1=z1-1
		if(d1<0):	
			d1=k11	
	
		k=0
		print(" "*row,end="")
		k=k+row	
		while(k<len(z) and i<len(z)):
			if(row==0 or row==(d-1)):
				print(z[i],end="")
				matrix[row][k]=z[i]				
				dec=dec+z[i]
				k=k+1
				i=i+1
				print(" "*d1,end="")
				k=k+d1
				continue
			else:
				print(z[i],end="")
				matrix[row][k]=z[i]				
				dec=dec+z[i]
				k=k+1
				i=i+1
				print(" "*d1,end="")
				k=k+d1			
				d1=z1-d1
				continue
			
		else:
			print("")
			row=row+1
			continue
	print(matrix)
	matrix=decconvert(matrix,len(z))	
	answer=int(input("is it readable 1->yes 2->no"))
	if(answer==1 and cry==1):
		f1=open("decryption.txt","w+")
		f1.write(matrix)
		sys.exit(0)
		
d=int(input("enter depth for decryption"))
z=open("encrypted.txt","r+").read()
decryption(z,d)
def crypanalysis(z):
	for i in range(2,len(z)+1):
		decryption(z,i,1)
		
crypanalysis(z)		
